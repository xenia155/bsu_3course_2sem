/**
 * Пакет fraction представляет собой набор примеров,
 * иллюстрирующих использование тегов javadoc.
 * Примечание. Эта сводка пакета, как и ВСЕ
 сводки * пакетов, должна находиться в файле с именем
 * <code>package-info.java</code>
 * @version 1.1
 * @author Chernyshova Ksenia
 */
package fraction;